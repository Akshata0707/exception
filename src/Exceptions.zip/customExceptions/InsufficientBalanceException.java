package customExceptions;

public class InsufficientBalanceException extends Exception {

	InsufficientBalanceException(String s){
		super(s);
	}
}
